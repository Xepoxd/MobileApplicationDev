import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';


const firebaseConfig = {
  apiKey: "AIzaSyB8hVwX0kWrPZEL6tFzUmMdu6UycROAwmc",
  authDomain: "foodapp-45c2e.firebaseapp.com",
  projectId: "foodapp-45c2e",
  storageBucket: "foodapp-45c2e.firebasestorage.app",
  messagingSenderId: "9415735427",
  appId: "1:9415735427:web:16af9956bb2b71461043b6",
  measurementId: "G-ZMQP5BD7P7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth, createUserWithEmailAndPassword, signInWithEmailAndPassword };
