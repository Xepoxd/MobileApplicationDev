import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSelector } from 'react-redux';

const ProfileScreen = () => {
  const [storedLocation, setStoredLocation] = useState(null);
  const location = useSelector((state) => state.user.location);

  useEffect(() => {
    const fetchLocation = async () => {
      const locationData = await AsyncStorage.getItem('userLocation');
      setStoredLocation(JSON.parse(locationData));
    };
    fetchLocation();
  }, []);

  return (
    <View>
      <Text>Welcome to your profile!</Text>
      {location && <Text>Current Location: {location.latitude}, {location.longitude}</Text>}
      {storedLocation && (
        <Text>Stored Location: {storedLocation.latitude}, {storedLocation.longitude}</Text>
      )}
    </View>
  );
};

export default ProfileScreen;
